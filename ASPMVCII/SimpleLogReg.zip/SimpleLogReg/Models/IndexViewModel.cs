namespace SimpleLogReg.Models
{
    public class IndexModels
    {
        public RegUser regUser {get; set;}
        public LogUser logUser {get; set;}
    }
}